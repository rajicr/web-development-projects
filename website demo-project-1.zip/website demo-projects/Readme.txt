project-1(Guess Game)

Guess Game is a virtual game between user and computer developed using HTML, CSS and JavaScript, which will tell the number of tries took by the computer for guessing the number of fingers holding by user. Here the user will the select the fingers from drop down box. 


project-2(Reaction Game)

How it Works

Reaction game application is developed using HTML, CSS and JavaScript which will generate random sized object at random positions on the screen and returns back how long it took for the user to hit the object in the screen.

Project-3(MiniForm)

How it Works

Miniform application will check for the proper format of the inputs (like email id, telephone number, password matching) provided in the field then returns the error message if the input format is not proper.

Project-4(BootStarp_demo)

How it Works

The application is a ready to use BootStrap Website where user can use the framework and modify accroding to there requirement.

Project-5(The Brighton Times)

How it Works

It is a replica of Brighton times website in which it has enhanced from non responsive website to highly responsive website.

Project-6(Testresponsive)

How it Works

Testresponsive website is a responsive website which is build to work on all type of device from mobile to laptop. Testresposive was designed to show how resposive the website can work across different screensize.